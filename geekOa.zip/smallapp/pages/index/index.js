//获取应用实例
const app = getApp()
Page({
  data: {
    motto: '极客壹佰OA管理系统'
  },
  onLoad: function() {
    var that = this;
  },
})