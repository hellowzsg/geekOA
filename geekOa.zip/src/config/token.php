<?php

return [
    // 驱动方式
    'type'     => 'Mysql',
    // 缓存前缀
    'key'      => 'i3d6o32wo8fvs1fvdpwens',
    // 加密方式
    'hashalgo' => 'ripemd160',
    // 缓存有效期 0表示永久缓存
    'expire'   => 0
];
