
{
    "code": 0,
    "msg": "ok",
    "count": 3,
    "data": [
        {
            "id": "10001",
            "name": "张三",
            "pinyin": "zhangsan",
            "department": "电商学院",
            "sex": "男"
        },
        {
            "id": "10002",
            "name": "李四",
            "pinyin": "lisi",
            "department": "高校学历部",
            "sex": "男"
        },
        {
            "id": "10003",
            "name": "王五",
            "pinyin": "wangwu",
            "department": "新媒体学院",
            "sex": "男"
        }
    ]
}