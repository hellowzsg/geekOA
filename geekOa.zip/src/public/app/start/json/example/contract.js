{
    "code": 0,
    "msg": "ok",
    "count": 3,
    "data": [
        {
            "orderid": "10001",
            "contract": "淘宝开店学习标准版",
            "contract_date": "2019.03.20-2019.05.19",
            "name": "张三",
            "pinyin": "zhangsan",
            "mobile": "13103771234",
            "sex": "男", 
            "detail": {
                "seller": "王五",
                "teacher": "李明",
                "amount": 200,
                "real_amount": 0,
                "remark": "合同的详细介绍"
            }
        },
        {
            "orderid": "10002",
            "contract": "淘宝开店学习标准版",
            "contract_date": "2019.03.20-2019.05.19",
            "name": "李四",
            "pinyin": "lisi",
            "mobile": "18766554433",
            "sex": "男",
            "detail": {
                "seller": "王五",
                "teacher": "李明",
                "amount": 200,
                "real_amount": 0,
                "remark": "合同的详细介绍"
            }
        },
        {
            "orderid": "10003",
            "contract": "设计推广",
            "contract_date": "2019.03.20-2019.05.19",
            "name": "王五",
            "pinyin": "wangwu",
            "mobile": "13333678800",
            "sex": "男",
            "detail": {
                "seller": "王五",
                "teacher": "李明",
                "amount": 200,
                "real_amount": 0,
                "remark": "设计推广合同的详细介绍"
            }
        }
    ]
}