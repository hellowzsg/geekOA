
{
    "code": 0,
    "msg": "ok",
    "count": 3,
    "data": [
        {
            "id": "10001",
            "name": "张三",
            "pinyin": "zhangsan",
            "mobile": "13103771234",
            "sex": "男"
        },
        {
            "id": "10002",
            "name": "李四",
            "pinyin": "lisi",
            "mobile": "18766554433",
            "sex": "男"
        },
        {
            "id": "10003",
            "name": "王五",
            "pinyin": "wangwu",
            "mobile": "13333678800",
            "sex": "男"
        }
    ]
}