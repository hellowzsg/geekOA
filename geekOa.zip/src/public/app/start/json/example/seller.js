
{
    "code": 0,
    "msg": "ok",
    "count": 3,
    "data": [
        {
            "id": "10001",
            "name": "张三",
            "pinyin": "zhangsan",
            "department": "销售一部",
            "sex": "男"
        },
        {
            "id": "10002",
            "name": "李四",
            "pinyin": "lisi",
            "department": "销售二部",
            "sex": "男"
        },
        {
            "id": "10003",
            "name": "王五",
            "pinyin": "wangwu",
            "department": "销售三部",
            "sex": "男"
        }
    ]
}