<?php

namespace app\common\model;

use think\Model;

class GeekUserinfo extends Model
{
    protected $pk = 'id';
}